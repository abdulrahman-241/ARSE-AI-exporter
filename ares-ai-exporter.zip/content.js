const aiDomains = [
  'chatgpt.com', 'openai.com', 'claude.ai', 'chat.z.ai', 'kimi.moonshot.cn', 'kimi.ai', 'kimi.com', 'chatglm.cn', 
  'deepseek.com', 'perplexity.ai', 'gemini.google.com', 'poe.com', 
  'copilot.microsoft.com', 'pi.ai', 'huggingface.co', 'qwenlm.ai', 'tongyi.aliyun.com', 'qwen.ai'
];

if (aiDomains.some(domain => window.location.hostname === domain || window.location.hostname.endsWith('.' + domain))) {

const container = document.createElement('div');
container.id = 'ai-exporter-container';

const menuContainer = document.createElement('div');
menuContainer.id = 'ai-exporter-menu';

const txtBtn = document.createElement('button');
txtBtn.innerHTML = '<span>⬇️</span> TXT';
txtBtn.className = 'ai-exporter-btn';
menuContainer.appendChild(txtBtn);

const pdfBtn = document.createElement('button');
pdfBtn.innerHTML = '<span>📄</span> PDF';
pdfBtn.className = 'ai-exporter-btn';
menuContainer.appendChild(pdfBtn);

const jsonBtn = document.createElement('button');
jsonBtn.innerHTML = '<span>{}</span> JSON';
jsonBtn.className = 'ai-exporter-btn';
menuContainer.appendChild(jsonBtn);

const mainBtn = document.createElement('button');
mainBtn.innerHTML = '<span>📥</span> Export';
mainBtn.className = 'ai-exporter-btn ai-exporter-main-btn';
mainBtn.addEventListener('click', () => {
  menuContainer.classList.toggle('show');
});

container.appendChild(menuContainer);
container.appendChild(mainBtn);

function ensureUI() {
  if (!document.getElementById('ai-exporter-container') && document.body) {
    document.body.appendChild(container);
  }
}

ensureUI();
setInterval(ensureUI, 1000);

function getChatData() {
  let exportText = "# Universal AI Chat Export\n\nThis document contains a structured conversation export.\n\n==================================================\n\n";
  let chatArray = [];
  const url = window.location.href;

  if (url.includes('chatgpt.com')) {
    const messages = document.querySelectorAll('[data-message-author-role]');
    messages.forEach(msg => {
      const role = msg.getAttribute('data-message-author-role');
      const text = msg.innerText;
      const roleName = role === 'user' ? 'User' : 'Assistant (ChatGPT)';
      exportText += `### Role: ${roleName}\n\n${text}\n\n==================================================\n\n`;
      chatArray.push({ role: roleName, content: text });
    });
  } else if (url.includes('claude.ai')) {
    const messages = document.querySelectorAll('.font-user-message, .font-claude-message');
    messages.forEach(msg => {
      const isUser = msg.classList.contains('font-user-message');
      const roleName = isUser ? 'User' : 'Assistant (Claude)';
      exportText += `### Role: ${roleName}\n\n${msg.innerText}\n\n==================================================\n\n`;
      chatArray.push({ role: roleName, content: msg.innerText });
    });
  } else {
    const selectors = [
      '[data-message-author-role]',
      '[data-role]',
      '.message', 
      '.chat-message', 
      '[class*="message"]', 
      '[class*="chat-bubble"]', 
      '[class*="bubble"]',
      '.ds-markdown', 
      '.markdown-body', 
      '.prose',
      '[class*="markdown"]'
    ].join(', ');
    
    let rawNodes = Array.from(document.querySelectorAll(selectors));
    rawNodes = rawNodes.filter(node => node.innerText && node.innerText.trim().length > 0);
    
    const filteredNodes = rawNodes.filter((node, index, self) => {
      return !self.some(otherNode => otherNode !== node && otherNode.contains(node));
    });

    if (filteredNodes.length > 0) {
      filteredNodes.forEach((msg, i) => {
        const text = msg.innerText.trim();
        exportText += `### Role: Participant ${i+1}\n\n${text}\n\n==================================================\n\n`;
        chatArray.push({ role: `Participant ${i+1}`, content: text });
      });
    } else {
      const pNodes = document.querySelectorAll('p');
      if (pNodes.length > 0) {
        pNodes.forEach((p, i) => {
          const text = p.innerText.trim();
          if (text.length > 0) {
            exportText += `### Role: Text Block ${i+1}\n\n${text}\n\n==================================================\n\n`;
            chatArray.push({ role: `Text Block ${i+1}`, content: text });
          }
        });
      } else {
        const text = document.body.innerText;
        exportText += `### Role: Document Content\n\n${text}\n\n==================================================\n\n`;
        chatArray.push({ role: 'Document Content', content: text });
      }
    }
  }
  
  if (chatArray.length === 0) {
    alert("No messages found on this page.");
    return null;
  }
  
  return { exportText, chatArray };
}

function downloadFile(content, mimeType, extension) {
  const blob = new Blob([content], { type: mimeType });
  const downloadUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = `ai-chat-export-${new Date().toISOString().slice(0, 10)}.${extension}`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(downloadUrl);
}

async function autoScroll() {
  const prevHtml = mainBtn.innerHTML;
  mainBtn.innerHTML = '<span>⏳</span> Scrolling...';
  menuContainer.classList.remove('show');
  
  const scrollers = [document.documentElement, document.body, ...Array.from(document.querySelectorAll('div, main, section'))].filter(el => {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    return (style.overflowY === 'auto' || style.overflowY === 'scroll') && el.scrollHeight > el.clientHeight;
  });

  const uniqueScrollers = [...new Set(scrollers)];

  // Scroll to top to trigger older lazy-loaded messages
  window.scrollTo(0, 0);
  uniqueScrollers.forEach(el => { el.scrollTop = 0; });
  await new Promise(r => setTimeout(r, 1000));
  
  // Scroll to bottom to ensure all content is loaded
  window.scrollTo(0, document.body.scrollHeight);
  uniqueScrollers.forEach(el => { el.scrollTop = el.scrollHeight; });
  await new Promise(r => setTimeout(r, 1000));

  mainBtn.innerHTML = prevHtml;
}

async function handleTxtExport() {
  await autoScroll();
  const data = getChatData();
  if (data) downloadFile(data.exportText, 'text/plain', 'txt');
}

async function handleJsonExport() {
  await autoScroll();
  const data = getChatData();
  if (data) downloadFile(JSON.stringify(data.chatArray, null, 2), 'application/json', 'json');
}

async function handlePdfExport() {
  await autoScroll();
  const data = getChatData();
  if (!data) return;
  
  if (!window.jspdf) {
    alert("PDF library not loaded properly.");
    return;
  }
  
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  
  doc.setFontSize(10);
  const splitText = doc.splitTextToSize(data.exportText, 180);
  
  let y = 10;
  for (let i = 0; i < splitText.length; i++) {
    if (y > 280) {
      y = 10;
      doc.addPage();
    }
    doc.text(splitText[i], 10, y);
    y += 5;
  }
  
  doc.save(`ai-chat-export-${new Date().toISOString().slice(0, 10)}.pdf`);
}

txtBtn.addEventListener('click', handleTxtExport);
jsonBtn.addEventListener('click', handleJsonExport);
pdfBtn.addEventListener('click', handlePdfExport);

document.addEventListener('keydown', async (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === 'x') {
    const active = document.activeElement.tagName;
    if (active === 'INPUT' || active === 'TEXTAREA' || document.activeElement.isContentEditable) return;
    
    e.preventDefault();
    pdfBtn.classList.add('loading');
    pdfBtn.innerHTML = '⏳ Processing...';
    
    await handlePdfExport();
    
    pdfBtn.classList.remove('loading');
    pdfBtn.innerHTML = '<span>📄</span> PDF';
  }
});

}
